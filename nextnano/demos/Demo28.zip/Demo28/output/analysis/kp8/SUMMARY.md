# chi2 result: kp8

| quantity | value |
|---|---|
| broadening Gamma | 5.0 meV = 0.005 eV, denominators `+iGamma` |
| wavelength | fundamental, 400-1850 nm, 1451 points |
| k points / solved k_max | 301 / 0.555714 nm^-1 (0.1000 pi/a) |
| integration cutoff | 0.555714 nm^-1 |
| integration | trapezoid over solved k points, measure g_s k dk/(2 pi), 0..k_max of the nextnano dispersion |
| energies | branch-resolved: chi2 averaged over the four lower/upper electron-hole branch pairings |
| pathways | 16 |
| prefactor | 56.698168825 pm/V per summand |
| states | {"e1": [11, 12], "e2": [13, 14], "hh1": [5, 6], "hh2": [1, 2]} |
| reference spectrum | none: no pre-existing spectrum for this mode; validated component by component (see VALIDATION.md) |

## Re chi2 zero crossings

| wavelength nm | Im chi2 pm/V | abs chi2 pm/V | abs/max abs |
|---:|---:|---:|---:|
| 690.6028 | 68.3792 | 68.3792 | 0.389 |
| 1388.5624 | -134.634 | 134.634 | 0.765 |

|Re| peaks (nm): [664, 732, 1327, 1464]  
|chi| peaks (nm): [668, 729, 1336, 1455]  
|chi| minima (nm): [697, 924, 1405]  
dominant |Re| peak 1327 nm; dominant |chi| peak 1336 nm (175.939 pm/V)

## Against digitized Fig. 2d (each curve normalized to its own maximum)

Best flat line: nRMSE 0.1904. An observable is informative only if it beats that and correlates at r >= 0.5.

| observable | nRMSE | correlation | beats flat line | informative |
|---|---:|---:|---|---|
| real | 0.418141 | 0.2191 | False | False |
| abs_real | 0.265419 | 0.0905 | False | False |
| abs | 0.321797 | -0.0943 | False | False |
| imag | 0.464937 | 0.2018 | False | False |

## Finding (computed)

```json
{
  "mechanism": {
    "question": "At the zeros of Re chi2, is Im chi2 (and therefore |chi2|) still finite?",
    "re_zero_count": 2,
    "at_re_zeros": [
      {
        "wavelength_nm": 690.6028394723754,
        "abs_real": 0.0,
        "abs_imag_over_max_abs": 0.38865362363249545,
        "abs_over_max_abs": 0.38865362363249545
      },
      {
        "wavelength_nm": 1388.5623689578279,
        "abs_real": 0.0,
        "abs_imag_over_max_abs": 0.7652309693182512,
        "abs_over_max_abs": 0.7652309693182512
      }
    ],
    "imag_nonzero_at_every_re_zero": true,
    "abs_nonzero_at_every_re_zero": true
  },
  "shape_comparison": {
    "question": "Does |Re chi2| or |chi2| actually reproduce the digitized Fig. 2d line shape?",
    "null_best_constant_nRMSE": 0.19039624538863967,
    "abs_real": {
      "nRMSE": 0.2654185028228117,
      "correlation": 0.0904979560023638,
      "beats_null": false,
      "informative": false
    },
    "abs": {
      "nRMSE": 0.32179662088140126,
      "correlation": -0.09430565961025163,
      "beats_null": false,
      "informative": false
    },
    "comparison_informative": false,
    "abs_real_closer_than_abs": true,
    "rule": "informative = nRMSE below the best flat line AND correlation >= 0.5"
  },
  "global_min_abs_over_max_abs_info": 0.006412118461764353,
  "note": "|Re chi2| is exactly zero at every refined Re zero crossing and |chi2| equals |Im chi2| there. Global minima include off-resonance spectral tails and are informational only.",
  "thresholds": {
    "imag_nonzero_fraction_of_max_abs": 0.05,
    "abs_nonzero_fraction_of_max_abs": 0.05
  }
}
```

## Sensitivity of the production choices

```json
{
  "doublet_averaged_energies": {
    "max_abs": 188.6265779483017,
    "dominant_abs_peak_nm": 1332.0,
    "re_zero_crossings_nm": [
      690.3807390910113,
      1388.1332621720444
    ],
    "nRMSE_abs_real": 0.2617350211310235,
    "nRMSE_abs": 0.3137320252994911,
    "max_abs_difference_over_production_max_abs": 0.12177001616149068
  },
  "overlap_weighted_by_conduction_block_amplitude": {
    "max_abs": 163.80103729157597,
    "dominant_abs_peak_nm": 1336.0,
    "re_zero_crossings_nm": [
      690.5663179688947,
      1388.4626675933514
    ],
    "nRMSE_abs_real": 0.26551296146172615,
    "nRMSE_abs": 0.3218181328740925,
    "max_abs_difference_over_production_max_abs": 0.06898811105511246
  }
}
```

## Limitations

- M(k)=M(0): kp8 spinors exported at k=0 only
- Energy-sorted dispersion columns (no finite-k spinor tracking); see min member gap
- Spin branches at k != 0 cannot be assigned without finite-k spinors; chi2 is averaged over the four lower/upper electron-hole branch pairings (splitting up to 11.7 meV)
- Dominant-block scalar envelopes renormalized to unit norm (Eq. 2 envelope-function factorization)
