# chi2 result: demo26-baseline

| quantity | value |
|---|---|
| broadening Gamma | 5.0 meV = 0.005 eV, denominators `+iGamma` |
| wavelength | fundamental, 400-1850 nm, 1451 points |
| k points / solved k_max | 301 / 0.555714 nm^-1 (0.1000 pi/a) |
| integration cutoff | 0.555714 nm^-1 |
| integration | trapezoid over solved k points, measure g_s k dk/(2 pi), 0..k_max of the nextnano dispersion |
| energies | doublet-averaged energies (historical) |
| pathways | 16 |
| prefactor | 56.698168825 pm/V per summand |
| states | {"electron": [1, 2], "valence": [1, 2], "kp8_pairs_for_dispersion": [[11, 12], [13, 14], [5, 6], [3, 4]]} |
| reference spectrum | {"reference_file": "baseline_reference.csv", "max_complex_error": 6.971134427479871e-10, "absolute_tolerance": 1e-08, "status": "PASS"} |

## Re chi2 zero crossings

| wavelength nm | Im chi2 pm/V | abs chi2 pm/V | abs/max abs |
|---:|---:|---:|---:|
| 714.0283 | 27.279 | 27.279 | 0.335 |
| 1437.4793 | -52.9968 | 52.9968 | 0.650 |

|Re| peaks (nm): [687, 753, 1374, 1505]  
|chi| peaks (nm): [688, 752, 1376, 1503]  
|chi| minima (nm): [720, 953, 1455]  
dominant |Re| peak 1505 nm; dominant |chi| peak 1503 nm (81.4907 pm/V)

## Against digitized Fig. 2d (each curve normalized to its own maximum)

Best flat line: nRMSE 0.1904. An observable is informative only if it beats that and correlates at r >= 0.5.

| observable | nRMSE | correlation | beats flat line | informative |
|---|---:|---:|---|---|
| real | 0.383379 | 0.3643 | False | False |
| abs_real | 0.237873 | 0.3096 | False | False |
| abs | 0.262391 | 0.2476 | False | False |
| imag | 0.491303 | -0.0292 | False | False |

## Finding (computed)

```json
{
  "mechanism": {
    "question": "At the zeros of Re chi2, is Im chi2 (and therefore |chi2|) still finite?",
    "re_zero_count": 2,
    "at_re_zeros": [
      {
        "wavelength_nm": 714.0283285725802,
        "abs_real": 0.0,
        "abs_imag_over_max_abs": 0.3347498768628388,
        "abs_over_max_abs": 0.3347498768628388
      },
      {
        "wavelength_nm": 1437.4792785382026,
        "abs_real": 0.0,
        "abs_imag_over_max_abs": 0.6503423920383483,
        "abs_over_max_abs": 0.6503423920383483
      }
    ],
    "imag_nonzero_at_every_re_zero": true,
    "abs_nonzero_at_every_re_zero": true
  },
  "shape_comparison": {
    "question": "Does |Re chi2| or |chi2| actually reproduce the digitized Fig. 2d line shape?",
    "null_best_constant_nRMSE": 0.19039624538863967,
    "abs_real": {
      "nRMSE": 0.23787347931114972,
      "correlation": 0.3096300795071214,
      "beats_null": false,
      "informative": false
    },
    "abs": {
      "nRMSE": 0.26239111786930097,
      "correlation": 0.24755539373543922,
      "beats_null": false,
      "informative": false
    },
    "comparison_informative": false,
    "abs_real_closer_than_abs": true,
    "rule": "informative = nRMSE below the best flat line AND correlation >= 0.5"
  },
  "global_min_abs_over_max_abs_info": 0.0049073899408546475,
  "note": "|Re chi2| is exactly zero at every refined Re zero crossing and |chi2| equals |Im chi2| there. Global minima include off-resonance spectral tails and are informational only.",
  "thresholds": {
    "imag_nonzero_fraction_of_max_abs": 0.05,
    "abs_nonzero_fraction_of_max_abs": 0.05
  }
}
```

## Limitations

- Historical mixed-model chain (single-band matrices, kp8 dispersion shape)
- Valence pair (3,4) selected by energy match is light-hole dominated
- M(k)=M(0)
