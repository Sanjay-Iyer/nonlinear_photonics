# Validation against pre-existing Demo 26 references

PASS 55 | FAIL 0 | NOT APPLICABLE 0 | NOT RUN 0

| category | PASS | FAIL | NOT APPLICABLE |
|---|---:|---:|---:|
| reference | 30 | 0 | 0 |
| consistency | 22 | 0 | 0 |
| independent_rederivation | 3 | 0 | 0 |

Dataset conditions: `{"kp8_deck_matches_reference": true, "case04_deck_matches_reference": true, "config_matches_reference": true}`

| mode | category | check | status | computed | reference | tol | source |
|---|---|---|---|---|---|---|---|
| demo26-baseline | reference | spectrum_max_complex_error | **PASS** | 6.971134427e-10 | 1e-08 | None | validation/baseline_reference.csv (= 23D_chi2.csv) |
| demo26-baseline | reference | re_zero_crossings_nm | **PASS** | [714.0283285725802, 1437.4792785382026] | [714.0286425430866, 1437.4801147300982] | 0.01 | DEMO26_REAL_ZERO_CROSSINGS.csv |
| demo26-baseline | reference | imag_at_re_zero_crossings | **PASS** | [27.278991400142317, -52.99683658085765] | [27.278972623707087, -52.99692881378773] | 0.005 | DEMO26_REAL_ZERO_CROSSINGS.csv |
| demo26-baseline | reference | nRMSE_abs | **PASS** | 0.2623911179 | 0.2623911179 | 1e-06 | audit TEST 01 |
| demo26-baseline | reference | nRMSE_real | **PASS** | 0.3833787753 | 0.3833787753 | 1e-06 | audit TEST 02 |
| demo26-baseline | reference | nRMSE_abs_real | **PASS** | 0.2378734793 | 0.2378734793 | 1e-06 | audit TEST 03 |
| demo26-baseline | reference | abs_real_peaks_nm | **PASS** | [687.0, 753.0, 1374.0, 1505.0] | [753.0, 1505.0] | 1 | audit TEST 03 P2/P4 |
| demo26-baseline | reference | dominant_abs_peak_nm | **PASS** | 1503 | 1503 | 0.5 | kmax_convergence.csv 23D 0.1 |
| demo26-baseline | reference | max_abs | **PASS** | 81.49066896 | 81.49066896 | 1e-06 | kmax_convergence.csv 23D 0.1 |
| demo26-baseline | reference | abs_at_1550nm | **PASS** | 26.48224695 | 26.48224695 | 1e-06 | kmax_convergence.csv 23D 0.1 |
| demo26-baseline | reference | k_points | **PASS** | 301 | 301 | None | kmax_convergence.csv |
| demo26-baseline | reference | k_max_per_nm | **PASS** | 0.5557144392 | 0.5557144392 | 1e-09 | kmax_convergence.csv |
| demo26-baseline | reference | kp8_pair_ids | **PASS** | [[11, 12], [13, 14], [5, 6], [3, 4]] | [[11, 12], [13, 14], [5, 6], [3, 4]] | None | RAW_K0_STATE_CHARACTER.csv production labels |
| demo26-baseline | reference | gamma_eV | **PASS** | 0.005 | 0.005 | 1e-15 | paper Methods / demo23_config |
| demo26-baseline | reference | wavelength_points | **PASS** | 1451 | 1451 | None | 400-1850 nm, 1 nm |
| demo26-baseline | reference | prefactor_pm_per_V | **PASS** | 56.69816882 | 56.69816882 | 1e-12 | Demo 21 walkthrough |
| demo26-baseline | consistency | k_weights_relative_error | **PASS** | 2.82355823e-16 | 1e-12 | None | sum g_s k dk/(2 pi) = g_s k_max^2/(4 pi) |
| demo26-baseline | consistency | eq2_diagonal_cancellation_max_abs_change | **PASS** | 2.291476225e-12 | 1e-08 | None | adding c*I to Ze and Zh cancels between conduction and valence terms |
| demo26-baseline | consistency | modulus_identity_max_error | **PASS** | 1.421085472e-14 | 1e-09 | None | |chi| = sqrt(Re^2 + Im^2) |
| demo26-baseline | consistency | pathway_sum_max_error | **PASS** | 0 | 1e-09 | None | chi = sum of the 16 pathway terms |
| demo26-baseline | consistency | pathway_count | **PASS** | 16 | 16 | None | Eq. 2: 8 conduction + 8 valence |
| demo26-cutoff | reference | spectrum_max_complex_error | **PASS** | 6.946157297e-05 | 0.0001 | None | validation/cutoff_reference.csv (6 significant digits) |
| demo26-cutoff | reference | re_zero_crossings_nm | **PASS** | [617.3429054925097, 1326.5156620085313] | [617.3432226355739, 1326.515321297561] | 0.01 | saved cutoff spectrum |
| demo26-cutoff | reference | imag_over_max_abs_real_at_re_zero | **PASS** | [0.29085733068467046, -0.6226780415727309] | [0.2908581665096464, -0.6226793625521313] | 0.002 | saved cutoff spectrum |
| demo26-cutoff | reference | nRMSE_abs_real | **PASS** | 0.06575171866 | 0.06575167751 | 0.0002 | saved cutoff spectrum + paper |
| demo26-cutoff | reference | nRMSE_abs | **PASS** | 0.2373761293 | 0.2373760645 | 0.0002 | saved cutoff spectrum + paper |
| demo26-cutoff | reference | legacy_max_abs_real | **PASS** | 41.17713972 | 41.1771 | 0.0001 | saved cutoff spectrum |
| demo26-cutoff | reference | integration_cutoff_per_nm | **PASS** | 1.111419049 | 1.111419049 | 1e-12 | 0.1 x 2pi/a, a = 0.56533 nm (CUTOFF_ARTIFACT_FINDING) |
| demo26-cutoff | consistency | modulus_identity_max_error | **PASS** | 1.421085472e-14 | 1e-09 | None | |chi| = sqrt(Re^2 + Im^2) |
| demo26-cutoff | consistency | pathway_sum_max_error | **PASS** | 0 | 1e-09 | None | chi = sum of the 16 pathway terms |
| demo26-cutoff | consistency | pathway_count | **PASS** | 16 | 16 | None | Eq. 2: 8 conduction + 8 valence |
| kp8 | reference | selected_states | **PASS** | {"e1": [11, 12], "e2": [13, 14], "hh1": [5, 6], "hh2": [1, 2 | {"e1": [11, 12], "e2": [13, 14], "hh1": [5, 6], "hh2": [1, 2 | None | RAW_K0_STATE_CHARACTER.csv + documented rule (CB>=0.8 lowest two; HH>=0.8 highest two) |
| kp8 | reference | k0_energies_eV | **PASS** | [2.9525116792099, 3.09114845201545, 1.4437721218703, 1.39769 | [2.95251167921, 3.091148452015, 1.44377212187, 1.39769425308 | 1e-09 | raw energy_spectrum_k00000.dat |
| kp8 | reference | abs_zh12_nm | **PASS** | 1.353216416 | 1.353216277 | 0.0001 | nextnano kp8 dipole_moment_matrix_elements (Kramers invariant) |
| kp8 | reference | abs_ze12_nm | **PASS** | 1.293211542 | 1.295475185 | 0.01 | nextnano kp8 dipole_moment_matrix_elements (includes non-CB spinor weight) |
| kp8 | reference | k_points | **PASS** | 301 | 301 | None | kVectors_Gamma_to_y.dat |
| kp8 | reference | gamma_eV | **PASS** | 0.005 | 0.005 | 1e-15 | paper Methods |
| kp8 | reference | prefactor_pm_per_V | **PASS** | 56.69816882 | 56.69816882 | 1e-12 | Demo 21 walkthrough |
| kp8 | independent_rederivation | abs_overlap_matrix | **PASS** | [[0.9900469636364996, 0.056865479332725795], [0.092985972143 | [[0.9900469636365046, 0.05686547933275442], [0.0929859721433 | 1e-08 | raw envelopes, largest-component extraction + Loewdin (no SVD) |
| kp8 | independent_rederivation | abs_ze_matrix | **PASS** | [[12.806182945137397, 1.2932115420601882], [1.29321154206018 | [[12.806182945137397, 1.293211542060136], [1.293211542060136 | 1e-08 | raw envelopes, largest-component extraction + Loewdin (no SVD) |
| kp8 | independent_rederivation | abs_zh_matrix | **PASS** | [[12.653915536635315, 1.3532164159194828], [1.35321641591948 | [[12.653915536635036, 1.3532164159202347], [1.35321641592023 | 1e-08 | raw envelopes, largest-component extraction + Loewdin (no SVD) |
| kp8 | consistency | zh12_vs_this_dataset_nextnano_dipole_rel | **PASS** | 1.025859061e-07 | 0.0001 | None | package |Zh12| vs the analysed dataset's own nextnano dipole file |
| kp8 | consistency | ze12_vs_this_dataset_nextnano_dipole_rel | **PASS** | 0.001747345707 | 0.01 | None | package |Ze12| vs the analysed dataset's own nextnano dipole file |
| kp8 | consistency | orthonormality_error_after_lowdin | **PASS** | 6.661338148e-16 | 1e-10 | None | definition |
| kp8 | consistency | max_envelope_second_singular_fraction | **PASS** | 2.542990948e-24 | 1e-06 | None | one scalar envelope per doublet block |
| kp8 | consistency | max_envelope_imaginary_residue | **PASS** | 1.848958685e-25 | 1e-06 | None | envelope real after a global phase |
| kp8 | consistency | composition_file_max_abs_difference | **PASS** | 9.153537928e-10 | 1e-06 | None | raw spinor_composition_k00000_CbHhLhSo.dat |
| kp8 | consistency | origin_invariance_max_abs_change | **PASS** | 2.224791219e-12 | 1e-08 | None | z origin shifted by 20 nm inside the envelope integrals |
| kp8 | consistency | origin_sensitivity_without_lowdin_max_abs_change | **PASS** | 2.190520692 | 0.001 | None | same shift WITHOUT Loewdin must change chi2, proving the origin check can fail |
| kp8 | consistency | min_member_gap_eV | **PASS** | 0.01183802441 | 0.005 | None | each selected branch stays >= Gamma from every other dispersion column |
| kp8 | consistency | k_weights_relative_error | **PASS** | 2.82355823e-16 | 1e-12 | None | sum g_s k dk/(2 pi) = g_s k_max^2/(4 pi) |
| kp8 | consistency | eq2_diagonal_cancellation_max_abs_change | **PASS** | 1.423308624e-12 | 1e-08 | None | adding c*I to Ze and Zh cancels between conduction and valence terms |
| kp8 | consistency | modulus_identity_max_error | **PASS** | 2.842170943e-14 | 1e-09 | None | |chi| = sqrt(Re^2 + Im^2) |
| kp8 | consistency | pathway_sum_max_error | **PASS** | 2.96073397e-13 | 1e-09 | None | chi = sum of the 16 pathway terms |
| kp8 | consistency | pathway_count | **PASS** | 16 | 16 | None | Eq. 2: 8 conduction + 8 valence |
