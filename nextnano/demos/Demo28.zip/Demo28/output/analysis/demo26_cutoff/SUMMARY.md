# chi2 result: demo26-cutoff

| quantity | value |
|---|---|
| broadening Gamma | 5.0 meV = 0.005 eV, denominators `+iGamma` |
| wavelength | fundamental, 400-1850 nm, 1451 points |
| k points / solved k_max | 301 / 0.555714 nm^-1 (0.1000 pi/a) |
| integration cutoff | 1.11142 nm^-1 |
| integration | analytic 2D integral of extrapolated parabolas, measure g_s k dk/(2 pi), 0..cutoff |
| energies | parabolas E0 + A k^2 fitted to the doublet-averaged baseline dispersion |
| pathways | 16 |
| prefactor | 56.698168825 pm/V per summand |
| states | {"electron": [1, 2], "valence": [1, 2], "kp8_pairs_for_dispersion": [[11, 12], [13, 14], [5, 6], [3, 4]]} |
| reference spectrum | {"reference_file": "cutoff_reference.csv", "max_complex_error": 6.946157296516982e-05, "absolute_tolerance": 0.0001, "status": "PASS"} |

## Re chi2 zero crossings

| wavelength nm | Im chi2 pm/V | abs chi2 pm/V | abs/max abs |
|---:|---:|---:|---:|
| 617.3429 | 34.4013 | 34.4013 | 0.272 |
| 1326.5157 | -73.6477 | 73.6477 | 0.581 |

|Re| peaks (nm): [546, 752, 1093, 1505]  
|chi| peaks (nm): [547, 752, 1093, 1503]  
|chi| minima (nm): [592, 831, 1254]  
dominant |Re| peak 1505 nm; dominant |chi| peak 1503 nm (126.672 pm/V)

## Against digitized Fig. 2d (each curve normalized to its own maximum)

Best flat line: nRMSE 0.1904. An observable is informative only if it beats that and correlates at r >= 0.5.

| observable | nRMSE | correlation | beats flat line | informative |
|---|---:|---:|---|---|
| real | 0.489925 | -0.0642 | False | False |
| abs_real | 0.065752 | 0.9413 | True | True |
| abs | 0.237376 | 0.4411 | False | False |
| imag | 0.689540 | 0.0340 | False | False |

## Finding (computed)

```json
{
  "mechanism": {
    "question": "At the zeros of Re chi2, is Im chi2 (and therefore |chi2|) still finite?",
    "re_zero_count": 2,
    "at_re_zeros": [
      {
        "wavelength_nm": 617.3429054925097,
        "abs_real": 0.0,
        "abs_imag_over_max_abs": 0.2715791580966111,
        "abs_over_max_abs": 0.2715791580966111
      },
      {
        "wavelength_nm": 1326.5156620085313,
        "abs_real": 0.0,
        "abs_imag_over_max_abs": 0.5814066226128698,
        "abs_over_max_abs": 0.5814066226128698
      }
    ],
    "imag_nonzero_at_every_re_zero": true,
    "abs_nonzero_at_every_re_zero": true
  },
  "shape_comparison": {
    "question": "Does |Re chi2| or |chi2| actually reproduce the digitized Fig. 2d line shape?",
    "null_best_constant_nRMSE": 0.19039624538863967,
    "abs_real": {
      "nRMSE": 0.0657517186573042,
      "correlation": 0.941344284390571,
      "beats_null": true,
      "informative": true
    },
    "abs": {
      "nRMSE": 0.23737612929624963,
      "correlation": 0.44113481130077487,
      "beats_null": false,
      "informative": false
    },
    "comparison_informative": true,
    "abs_real_closer_than_abs": true,
    "rule": "informative = nRMSE below the best flat line AND correlation >= 0.5"
  },
  "global_min_abs_over_max_abs_info": 0.02322925008754923,
  "note": "|Re chi2| is exactly zero at every refined Re zero crossing and |chi2| equals |Im chi2| there. Global minima include off-resonance spectral tails and are informational only.",
  "thresholds": {
    "imag_nonzero_fraction_of_max_abs": 0.05,
    "abs_nonzero_fraction_of_max_abs": 0.05
  }
}
```

## Limitations

- Historical mixed-model chain (single-band matrices, kp8 dispersion shape)
- Valence pair (3,4) selected by energy match is light-hole dominated
- M(k)=M(0)
- Parabolas extrapolated beyond the solved k range; case00 matrices with case04 energies
